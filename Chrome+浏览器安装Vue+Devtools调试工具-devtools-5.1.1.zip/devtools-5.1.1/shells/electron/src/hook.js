import { installHook } from 'src/backend/hook'
import { target } from 'src/devtools/env'

installHook(target)
