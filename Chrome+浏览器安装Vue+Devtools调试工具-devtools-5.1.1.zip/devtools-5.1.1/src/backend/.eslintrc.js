module.exports = {
  globals: {
    bridge: 'off'
  }
}